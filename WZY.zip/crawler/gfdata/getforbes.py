import pandas as pd

# 读取Excel文件，假设文件名为'your_file.xlsx'，并且C列有数据
# 如果你的Excel文件是.xls格式的，可能需要将engine参数更改为'xlrd'
df = pd.read_excel(r'source_files\companies.xlsx', engine='openpyxl')

# 提取C列的内容
column_c = df.iloc[:, 2]  # 使用iloc基于整数位置的索引（C列是第三列，索引为2）
# 或者使用列名（如果列有标题的话）
# column_c = df['C']

# 打印C列的内容
# print(column_c)

# 如果你想要将C列的内容保存到一个新的列表中
column_c_list = column_c.tolist()
print(column_c_list)