import pandas as pd
import os
import datetime

def main():
    # 假设所有的JSON文件都位于同一个目录下，例如'json_files'
    json_dir = r'D:\Pythonprojects\pythonProject1\crawler\gfdata\2024_7_10'
    result_dir = r'D:\Pythonprojects\pythonProject1\crawler\gfdata\result_files'
    # 获取当前时间
    now = datetime.datetime.now()
    # 格式化时间字符串，例如 "2023-07-19_12-34-56"
    excel_name = now.strftime("%Y-%m-%d_%H-%M-%S")+'.xlsx'
    excel_file = os.path.join(result_dir, excel_name)
    sheet_name = 'Sheet1'  # Excel工作表名称

    # 初始化一个空的DataFrame
    all_data = pd.DataFrame()
    # 使用ExcelWriter对象来写入Excel文件（如果文件已存在，会被覆盖）
    with pd.ExcelWriter(excel_file, engine='openpyxl', mode='w') as writer:
        for filename in os.listdir(json_dir):
            if filename.endswith('.json'):  # 确保文件是JSON格式
                file_path = os.path.join(json_dir, filename)
                # 读取JSON文件到DataFrame
                df = pd.read_json(file_path, lines=True)

                # 如果是第一个文件，则直接写入
                if all_data.empty:
                    all_data = df
                # 否则，将新的DataFrame追加到all_data中
                else:
                    all_data = pd.concat([all_data, df], ignore_index=True)

        # 在循环结束后，一次性写入Excel文件
        all_data.to_excel(writer, sheet_name=sheet_name, index=False)

    print(f"所有JSON文件的内容已成功写入{excel_file}")
if __name__ == '__main__':
    main()