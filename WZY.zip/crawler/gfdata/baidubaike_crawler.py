from selenium import webdriver
from selenium.common.exceptions import NoSuchElementException
from selenium.webdriver.chrome.service import Service
from webdriver_manager.chrome import ChromeDriverManager
from selenium.webdriver.common.by import By
from selenium.webdriver.chrome.options import Options
class BaikeNotFoundError(Exception):
    pass


def fetch_baike_content(baike_name):
    # 初始化WebDriver
    chrome_options = Options()
    chrome_options.add_argument("--headless")
    # driver = webdriver.Chrome(options=chrome_options)
    driver = webdriver.Chrome(service=Service(ChromeDriverManager().install()),options=chrome_options)

    # 构造词条页面的URL
    url = f"https://baike.baidu.com/item/{baike_name}"

    try:
        # 访问页面
        driver.get(url)

        # 这里假设未收录词条页面有一个特定的元素或文本，如“没有找到与XXX相关的词条”
        try:
            not_found_element = driver.find_element(by=By.XPATH, value='/html/body/div[2]/div[1]/div[1]') # 替换为你的XPath表达式
            content = 'pass'
            # raise BaikeNotFoundError("该词条未被收录")
        except NoSuchElementException:
            # 如果找不到未收录的元素，则继续提取内容
            pass

            parent_element = None
            # 提取词条内容
            try:
                parent_element = driver.find_element(by=By.XPATH, value='/html/body/div[1]/div/div[2]')
            except NoSuchElementException:
                content = 'pass'
            if parent_element != None:
                try:
                    for child in parent_element.find_elements(by=By.TAG_NAME, value='h1'):
                        title = child.text  # 标题
                except NoSuchElementException:
                    title = None
                try:
                    intro_expression = '//div[contains(@class, "lemmaSummary")]'# <div class="lemmaSummary_eXXTS J-summary">
                    for child in parent_element.find_elements(by=By.XPATH, value=intro_expression):
                        intro = child.text
                except NoSuchElementException:
                    intro = None
                try:
                    name_CH = parent_element.find_element(By.XPATH,'.//dd[preceding-sibling::dt[contains(text(), "中文名")]]/span').text.strip()
                except NoSuchElementException:
                    name_CH = None
                try:
                    name_EN = parent_element.find_element(By.XPATH,'.//dd[preceding-sibling::dt[contains(text(), "外文名")]]/span').text.strip()
                except NoSuchElementException:
                    name_EN = None
                try:
                    duty = parent_element.find_element(By.XPATH,'.//dd[preceding-sibling::dt[contains(normalize-space(text()), "职\u00A0\u00A0\u00A0\u00A0责")]]/span').text.strip()
                except NoSuchElementException:
                    duty = None
                content = {"标题": title, "介绍": intro, "中文名": name_CH, "外文名": name_EN, "职责": duty}

            # 关闭浏览器（可选）
            # driver.quit()

        return content

    except BaikeNotFoundError as e:
        print(e)
        # 关闭浏览器（可选）
        driver.quit()
        return None

    except Exception as e:
        print(f"发生错误: {e}")
        # 关闭浏览器（可选）
        driver.quit()
        return None

    # 示例词条名（请替换为实际的词条名）


# baike_name = '孟加拉国军队'
baike_name = '美国国防高级研究计划局'
content = fetch_baike_content(baike_name)
if content:
    print(content)

