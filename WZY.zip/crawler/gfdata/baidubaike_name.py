from selenium import webdriver
from selenium.common.exceptions import NoSuchElementException, TimeoutException
from selenium.webdriver.chrome.service import Service
from webdriver_manager.chrome import ChromeDriverManager
from selenium.webdriver.common.by import By
from selenium.webdriver.chrome.options import Options
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC
from selenium.webdriver.common.keys import Keys
import time
import random
class BaikeNotFoundError(Exception):
    pass

# 设置超时时间
timeout = 10

def fetch_baike_content(baike_name):
    # 初始化WebDriver
    chrome_options = Options()
    chrome_options.add_argument("--headless")
    driver = webdriver.Chrome(service=Service(ChromeDriverManager().install()),options=chrome_options)
    # driver = webdriver.Chrome(service=Service(ChromeDriverManager().install()))
    urlnames = ['俄罗斯联邦国防部','美国国防部高级研究计划局','美国导弹防御局','美国空军装备司令部','白俄罗斯国立医科大学','新西兰国防军','法国国防部','希腊空军','伊拉克国防','马来西亚皇家空军']
    i = random.randint(0, 9)
    # 构造词条页面的URL
    url = f"https://baike.baidu.com/item/{urlnames[i]}"

    content =[]
    try:
        # 访问页面
        driver.get(url)
        time.sleep(1)
        # 使用XPath找到input元素
        search_input = driver.find_element(By.CLASS_NAME, 'searchInput')

        # 输入新词条
        search_input.clear()  # 清除现有内容
        search_input.send_keys(baike_name)
        # wait = WebDriverWait(driver, 3)
        # 找到按钮并点击
        # 假设按钮的类名为'siteBtn'，并且这个类名在页面中唯一
        button = driver.find_element(By.CLASS_NAME, 'siteBtn')
        driver.execute_script("arguments[0].click();", button)
        # button.click()
        # page_content = driver.page_source
        # print(page_content)
        content = []
        page = 1
        while True:
            time.sleep(1)
            # 查找em元素并处理（这里只是打印它们的文本作为示例）
            try:
                # em_expression = r'//a[@class="title_lkpex“]'
                em_elements = driver.find_elements(by=By.CLASS_NAME, value='title_lkpex')#
                for em in em_elements:
                    content.append(em.text)
                # return content
                page = page + 1
            except NoSuchElementException:
                # 如果没有找到em元素，可以忽略或处理异常（这里选择忽略）
                pass

            # 查找下一页按钮
            try:
                next_page_element = driver.find_element(by=By.XPATH, value=r'//span[contains(text(), "下一页")]')# <span class="pagerItem_geff5 next_Vmga_">下一页&gt;</span>
                # next_page_element = WebDriverWait(driver, 10).until(
                #     EC.presence_of_element_located((By.XPATH, '//span[contains(text(), "下一页")]'))
                # )
                driver.execute_script("arguments[0].click();", next_page_element)
                # next_page_element.click()

                # 等待页面加载完成（如果需要）
                # 这里可以根据实际情况添加等待逻辑，比如等待某个元素出现

            except NoSuchElementException:
                # 如果没有找到下一页按钮，则退出循环
                break

            except TimeoutException:
                # 如果等待超时（比如页面加载过慢），可以选择重试、记录日志或退出
                break
                # 关闭浏览器（可选）
                # driver.quit()
        return content

    except BaikeNotFoundError as e:
        print(e)
        # 关闭浏览器（可选）
        # driver.quit()
        return None

    except Exception as e:
        print(f"发生错误: {e}")
        # 关闭浏览器（可选）
        # driver.quit()
        return None

with open(r'2024_7_10\countries.txt','r',encoding='utf-8')as countries:
    for line in countries:
        baike_name = f'{line.strip()}国防'
        print(baike_name)
        # baike_name = '美国国防高级研究计划局'
        content = fetch_baike_content(baike_name)
        if content:
            with open(r'2024_7_10\gfnames.txt','a',encoding='utf-8')as names:
                for item in content:
                    names.write(item+'\n')

