# 假设的“科技相关”SIC代码列表
tech_related_sics = set(range(3570, 3580)) | set(range(3660, 3670)) | set(range(3670, 3680)) | set(range(3800, 3900))# 示例范围，实际应根据需要调整

# 打开文件并读取内容
# with open('2024_7_3\sub.txt', 'r', encoding='utf-8') as file:
#     with open('2024_7_3\companies_2.txt', 'w', encoding='utf-8') as file2:
#         # 跳过第一行（列标题）
#         next(file)
#         # 逐行读取并筛选科技相关公司
#         for line in file:
#             # 假设SIC代码是每行的第一个由空格分隔的字段
#             # 注意：这可能需要根据你的实际文件格式进行调整
#             parts = line.strip().split()
#             if parts:
#                 sic_code = int(parts[3])  # 将SIC代码转换为整数以便比较
#                 if sic_code in tech_related_sics:
#                     # 提取公司名称（这里假设是第三个字段，但可能需要根据实际情况调整）
#                     company_name = parts[2]
#                     file2.write(company_name+'\n')
# 打开文件并读取内容
with open('2024_7_3\sub.txt', 'r', encoding='utf-8') as file:
    # 跳过第一行（列标题）
    next(file)
    # 逐行读取并提取公司名称
    for line in file:
        # 使用空格分割每行
        parts = line.strip().split()
        # 假设公司名称是第三列（索引为2，因为索引从0开始）
        company_name = parts[2]
        print(company_name)
