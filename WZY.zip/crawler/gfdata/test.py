import baidubaike_crawler
import wikibaike_crawler
import random
import time
import json
import os
import json2excel

# 主函数
def main():
    source_dir = r'2024_7_10'
    result_dir = r'2024_7_10'
    for filename in os.listdir(source_dir):
        if filename.endswith('.txt'):
            file_path = os.path.join(source_dir, filename)

            # 文件读取景点信息
            with open(file_path, 'r',encoding='utf-8')as source:
                resultname = filename[:-4]+'.json'
                result_path = os.path.join(result_dir, resultname)
                for line in source:
                    name = line.strip()
                    with open(result_path,'a', encoding='utf-8') as result:
                        print(name)
                        content = baidubaike_crawler.fetch_baike_content(name)
                        # content = wikibaike_crawler.fetch_baike_content(name)
                        # print(content)
                        if type(content) == dict:
                            result.write(json.dumps(content,ensure_ascii=False))  # ensure_ascii=False确保非ASCII字符被正确写入，indent=4用于缩进增加可读性
                            result.write('\n')
                    result.close()
                    # time.sleep(random.uniform(2, 5))

            source.close()
    json2excel.main()

if __name__ == '__main__':
    main()