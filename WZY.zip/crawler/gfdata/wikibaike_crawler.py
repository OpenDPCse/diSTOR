from selenium import webdriver
from selenium.common.exceptions import NoSuchElementException
from selenium.webdriver.chrome.service import Service
from webdriver_manager.chrome import ChromeDriverManager
from selenium.webdriver.common.by import By
from selenium.webdriver.chrome.options import Options
class BaikeNotFoundError(Exception):
    pass


def fetch_baike_content(baike_name):
    # 初始化WebDriver
    # chrome_options = Options()
    # chrome_options.add_argument("--headless")
    # driver = webdriver.Chrome(options=chrome_options)
    # driver = webdriver.Chrome(service=Service(ChromeDriverManager().install()),options=chrome_options)
    driver = webdriver.Chrome(service=Service(ChromeDriverManager().install()))

    # 构造词条页面的URL
    url = f"https://wiki.tuftech.org/wiki/{baike_name}"

    try:
        # 访问页面
        driver.get(url)

        # 这里假设未收录词条页面有一个特定的元素或文本，如“没有找到与XXX相关的词条”
        try:
            not_found_element = driver.find_element(by=By.XPATH, value='/html/body/div[2]/div/div[3]/main/div[3]/div[3]/div[1]/div/p/b') # 替换为你的XPath表达式
            content = 'pass'
            # raise BaikeNotFoundError("该词条未被收录")
        except NoSuchElementException:
            # 如果找不到未收录的元素，则继续提取内容
            pass

            parent_element = None
            # 提取词条内容
            try:
                parent_element = driver.find_element(by=By.XPATH, value='/html/body/div[2]/div/div[3]/main')
            except NoSuchElementException:
                content = 'pass'
            if parent_element != None:
                try:
                    for child in parent_element.find_elements(by=By.CLASS_NAME, value='mw-page-title-main'):# <span class="mw-page-title-main">丹麦皇家空军</span>
                        title = child.text  # 标题
                except NoSuchElementException:
                    title = None
                try:
                    # intro_expression = '//div[contains(@class, "lemmaSummary")]'# <div class="lemmaSummary_eXXTS J-summary">
                    intro = parent_element.find_element(by=By.TAG_NAME, value='p').text# /html/body/div[2]/div/div[3]/main/div[3]/div[3]/div[1]/p
                except NoSuchElementException:
                    intro = None
                #
                content = {"标题": title, "介绍": intro,"中文名":None,"外文名":None,"职责":None}

            # 关闭浏览器（可选）
            # driver.quit()

        return content

    except BaikeNotFoundError as e:
        print(e)
        # 关闭浏览器（可选）
        driver.quit()
        return None

    except Exception as e:
        print(f"发生错误: {e}")
        # 关闭浏览器（可选）
        driver.quit()
        return None

    # 示例词条名（请替换为实际的词条名）


# baike_name = '孟加拉国军队'
baike_name = '丹麦皇家空军'
content = fetch_baike_content(baike_name)
if content:
    print(content)


