import json
import re

def extract_chinese(text):
    # 使用正则表达式匹配所有中文字符
    # [\u4e00-\u9fff] 是中文字符的大致范围（基本涵盖了常用汉字）
    # [\u3400-\u4dbf] 是扩展A区，包括了一些生僻字和古代汉字
    # 可以根据需要添加更多的Unicode范围
    # chinese_chars = re.findall(r'[\u4e00-\u9fff]+', text)
    chinese_chars = re.findall(r'[\u4e00-\u9fa5，。？！：；“”‘’《》【】（）％＄＃＠＆＊（）－＋＝｜《》〈〉【】〔〕｛｝「」『』【】〔〕［］｛｝（）､、〒〓〈〉《》「」『』【】〔〕〖〗〘〙〚〛〜〝〞〟〰〾〿–—‘’‛“”„‟…‧﹏．。？！：；，。？！、，]',text)
    # 将找到的中文文字列表合并成一个字符串
    return ''.join(chinese_chars)
# def extract_chinese_with_numbers(text):# 匹配数字失败了，会匹配到多余的数字，最终只匹配了汉字和标点符号
#     # 使用正则表达式匹配所有中文字符和数字
#     # [\u4e00-\u9fff] 是中文字符的大致范围（基本涵盖了常用汉字）
#     # [\u3400-\u4dbf] 是扩展A区，包括了一些生僻字和古代汉字
#     # \d 匹配数字0-9
#     chinese_and_numbers = re.findall(r'[\u4e00-\u9fff\u3400-\u4dbf\d]+', text)
#     # 将找到的中文文字和数字列表合并成一个字符串
#     return ''.join(chinese_and_numbers)

file_path = r"C:\Users\15231\Desktop\baike"
file_name = file_path + r"\baike_0.txt"
result_name = file_path + r"\result_0.json"
with open(file_name,'r',encoding='utf-8')as file:# 读取压缩包中的文件
    for line in file:# 提取主要内容
        data = json.loads(line)
        item_name = data['keyword']
        desc = extract_chinese(data['content'])
        url = data['url']
        data_dict={"item_name":item_name,"desc":desc,"area" : "null", "source_from" : "百度百科", "tags" :[], "text_type" : "null", "url" : url, "collect_time" : "20240913" }
        with open(result_name, 'a', encoding='utf-8') as result:
            # result.write(json.dumps(data_dict,ensure_ascii=False))
            json.dump(data_dict,result,ensure_ascii=False)
            result.write('\n')

