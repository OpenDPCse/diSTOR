from pymongo import MongoClient
import json
from bson import ObjectId

# 自定义JSON编码器来处理ObjectId
class MongoJSONEncoder(json.JSONEncoder):
    def default(self, obj):
        if isinstance(obj, ObjectId):
            return str(obj)
        return json.JSONEncoder.default(self, obj)

# 连接到MongoDB
client = MongoClient('localhost', 27017)
db = client['dataclear']  # 选择或创建数据库
collection = db['baike_0']  # 选择或创建集合

file_path = r"C:\Users\15231\Desktop\baike"
file_name = file_path + r"\result_0.json"
output_name = file_path + r"\output_0.json"

with open(file_name, 'r',encoding='utf-8') as file:
    for line in file:
        # 将数据传入mongodb
        name = json.loads(line.strip())  # 去除换行符
        # 插入文档
        collection.insert_one({'name': name})

print("导入完成")

# 打开文件准备写入
with open(output_name, 'w', encoding='utf-8') as f:
    # 遍历集合中的所有文档
    for doc in collection.find():
        # 将文档转换为JSON字符串并写入文件
        # 每个文档后添加一个换行符以便于阅读
        json.dump(doc, f, cls=MongoJSONEncoder, ensure_ascii=False, indent=4)
        f.write('\n')  # 在每个文档之间添加换行符，以便于阅读

# 关闭MongoDB连接（虽然在这个脚本中，当Python进程结束时，连接通常会自动关闭）
client.close()

