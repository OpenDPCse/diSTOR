from selenium import webdriver
from selenium.common.exceptions import NoSuchElementException
from selenium.webdriver.chrome.service import Service
from webdriver_manager.chrome import ChromeDriverManager
from selenium.webdriver.common.by import By
from selenium.common.exceptions import NoSuchElementException, TimeoutException
from selenium.webdriver.chrome.options import Options
import time
from io import BytesIO
import requests

class BaikeNotFoundError(Exception):
    pass


def fetch_amazon_content(goods_url):
    # 初始化WebDriver
    # chrome_options = Options()
    # chrome_options.add_argument("--headless")
    driver = webdriver.Chrome(service=Service(ChromeDriverManager().install()))
    # driver = webdriver.Chrome(service=Service(ChromeDriverManager().install()),options=chrome_options)

    # 构造词条页面的URL
    # url = f"https://www.amazon.com/"
    url = goods_url

    try:
        # 访问页面
        driver.get(url)
        time.sleep(10)
        # 这里假设未收录词条页面有一个特定的元素或文本，如“没有找到与XXX相关的词条”
        content={}
        title=''
        price=''
        intro=''
        try:
            title_element = driver.find_element(by=By.XPATH, value="//span[contains(@id, 'productTitle')]")
            title = title_element.text
        except NoSuchElementException:
            # 如果没有找到em元素，可以忽略或处理异常（这里选择忽略）
            pass
        try:
            price_element = driver.find_element(by=By.XPATH, value="//span[contains(@class, 'a-price')]")
            price = price_element.text
        except NoSuchElementException:
            # 如果没有找到em元素，可以忽略或处理异常（这里选择忽略）
            pass
        try:
            intro_element = driver.find_element(by=By.XPATH, value="//div[contains(@id, 'feature-bullets')]")
            intro = intro_element.text
        except NoSuchElementException:
            try:
                intro_element = driver.find_element(by=By.XPATH, value="//div[contains(@id, 'productFactsDesktopExpander')]")
                intro = intro_element.text
            except NoSuchElementException:
                try:
                    intro_element = driver.find_element(by=By.XPATH,value="//div[contains(@id, 'nic-po-expander')]")
                    intro = intro_element.text
                except NoSuchElementException:
                    # 如果没有找到em元素，可以忽略或处理异常（这里选择忽略）
                    pass
        content = {'url':goods_url,'title':title,'price':price,'intro':intro}
        time.sleep(5)
        return content

    except BaikeNotFoundError as e:
        print(e)
        # 关闭浏览器（可选）
        driver.quit()
        return None

    except Exception as e:
        print(f"发生错误: {e}")
        # 关闭浏览器（可选）
        driver.quit()
        return None

    # 示例词条名（请替换为实际的词条名）


goods_url = 'https://www.amazon.com/-/zh/dp/B0875LJP81/ref=cm_cr_arp_d_bdcrb_top?ie=UTF8&th=1'
# goods_url = 'https://www.amazon.com/-/zh/dp/B0BQ118F2T/ref=sr_1_1?__mk_zh_CN=%E4%BA%9A%E9%A9%AC%E9%80%8A%E7%BD%91%E7%AB%99&crid=1GXWWMCS3HITW&dib=eyJ2IjoiMSJ9.wwKEO2YZjaVbamMrjvBeC9laokd9yjzIQaqPLgItp0N1Rb4U8aUPez7WDoZ4f-7IjCWQm4IPyxKoaETsEPGRDBAQEzdbNxM2O7Cy350Ks7hdz9CrwlGRJ24PK7BVzN5c3WOe7As-9r4tZ7HR6n-yRf2OAx4K0X560oEsxMnT6Dnok5wr-HozNj64hmjuCIR22B2raIn463QMXSwneRnzj6pTytWdsamHO2nrX1UvDiQ.eU1JLRrnssp30HHyxgCzn4JNZQW_fp2wXbdKG1SZ50c&dib_tag=se&keywords=%E6%89%8B%E6%9C%BA&qid=1721805535&sprefix=%E6%89%8B%E6%9C%BA%2Caps%2C698&sr=8-1&th=1'
content = fetch_amazon_content(goods_url)
if content:
    print(content)

