from selenium import webdriver
from selenium.common.exceptions import NoSuchElementException
from selenium.webdriver.chrome.service import Service
from webdriver_manager.chrome import ChromeDriverManager
from selenium.webdriver.common.by import By
from selenium.common.exceptions import NoSuchElementException, TimeoutException
from selenium.webdriver.chrome.options import Options
import time
from PIL import Image
import pytesseract
class BaikeNotFoundError(Exception):
    pass


def fetch_amazon_content(goods_name):
    # 初始化WebDriver
    # chrome_options = Options()
    # chrome_options.add_argument("--headless")
    driver = webdriver.Chrome(service=Service(ChromeDriverManager().install()))
    # driver = webdriver.Chrome(service=Service(ChromeDriverManager().install()),options=chrome_options)

    # 构造词条页面的URL
    url = f"https://www.amazon.com/"

    try:
        # 访问页面
        driver.get(url)
        time.sleep(10)#流出时间手动输入验证码，可以找找有没有相关工具
        # 这里假设未收录词条页面有一个特定的元素或文本，如“没有找到与XXX相关的词条”
        search_input = driver.find_element(by=By.XPATH, value="//*[contains(@id, 'twotabsearchtextbox')]") # 找到输入查询对象的地方
        # 输入新词条
        search_input.clear()  # 清除现有内容
        search_input.send_keys(goods_name)
        # wait = WebDriverWait(driver, 3)
        # 找到按钮并点击
        # 假设Amazon的初始页面总是不变的
        button = driver.find_element(By.XPATH, "//*[contains(@id, 'nav-search-submit-button')]")
        driver.execute_script("arguments[0].click();", button)
        # button.click()
        # page_content = driver.page_source
        # print(page_content)
        content = []
        page = 1
        while True:
            time.sleep(1)
            # 查找em元素并处理（这里只是打印它们的文本作为示例）
            try:
                # 使用XPath查找所有具有特定类的a标签
                good = driver.find_element(By.XPATH,"//div[@CLASS='puisg-col puisg-col-4-of-12 puisg-col-8-of-16 puisg-col-12-of-20 puisg-col-12-of-24 puis-list-col-right']")# a-section a-spacing-small a-spacing-top-small
                # parent = driver.find_element(By.XPATH,
                                           # "//div[@class='s-main-slot s-result-list s-search-results sg-row']")
                links = good.find_elements(By.XPATH, "//a[contains(@class, 'a-link-normal s-underline-text s-underline-link-text s-link-style a-text-normal')]")
                for link in links:
                    href = link.get_attribute('href')
                    text = link.text
                    print(f'链接: {href}, 文本: {text}')
                print(len(links))
                # links = driver.find_elements(By.XPATH, "//a[contains(@class, 'a-link-normal s-underline-text s-underline-link-text s-link-style a-text-normal')]")
                #
                # # 遍历链接并提取href属性和文本内容
                # for link in links:
                #     href = link.get_attribute('href')
                #     text = link.text
                #     print(f'链接: {href}, 文本: {text}')
                # prices = driver.find_elements(By.XPATH, "//span[contains(@class, 'a-price')]")# #
                # for price in prices:
                #     good_price = price.text
                #     print(f'价格：{good_price}')
                    # 遍历链接并提取href属性和文本内容
                # for good in goods:
                #     href=''
                #     intro=''
                #     price=''
                #     try:
                #         link = good.find_element(By.XPATH,"//a[contains(@class, 'a-link-normal s-underline-text s-underline-link-text s-link-style a-text-normal')]")
                #         href = link.get_attribute('href')
                #         intro = link.text
                #         print(f'链接：{href}，介绍：{intro}')
                #     except NoSuchElementException:
                #         # 如果没有找到em元素，可以忽略或处理异常（这里选择忽略）
                #         pass
                #     try:
                #         price_element = good.find_element(By.XPATH,"//span[contains(@class, 'a-offscreen')]")
                #         price = price_element.text
                #         print(f'价格：{price}')
                #     except NoSuchElementException:
                #         # 如果没有找到em元素，可以忽略或处理异常（这里选择忽略）
                #         pass
                    # print(f'链接: {href}, 简介: {intro}, 价格：{price}')
                page = page + 1
            except NoSuchElementException:
                # 如果没有找到em元素，可以忽略或处理异常（这里选择忽略）
                pass
            # 查找下一页按钮
            try:
                next_page_element = driver.find_element(by=By.XPATH, value=r'//span[contains(text(), "下一页")]')# <span class="pagerItem_geff5 next_Vmga_">下一页&gt;</span>
                # next_page_element = WebDriverWait(driver, 10).until(
                #     EC.presence_of_element_located((By.XPATH, '//span[contains(text(), "下一页")]'))
                # )
                driver.execute_script("arguments[0].click();", next_page_element)
                # next_page_element.click()

                # 等待页面加载完成（如果需要）
                # 这里可以根据实际情况添加等待逻辑，比如等待某个元素出现

            except NoSuchElementException:
                # 如果没有找到下一页按钮，则退出循环
                break

            except TimeoutException:
                # 如果等待超时（比如页面加载过慢），可以选择重试、记录日志或退出
                break
                # 关闭浏览器（可选）
                # driver.quit()
        return content

    except BaikeNotFoundError as e:
        print(e)
        # 关闭浏览器（可选）
        driver.quit()
        return None

    except Exception as e:
        print(f"发生错误: {e}")
        # 关闭浏览器（可选）
        driver.quit()
        return None

    # 示例词条名（请替换为实际的词条名）


goods_name = '手机'
# # goods_name = '美国国防高级研究计划局'
content = fetch_amazon_content(goods_name)
if content:
    print(content)

