import random
import time
import json
import os
from selenium import webdriver
from selenium.common.exceptions import NoSuchElementException
from selenium.webdriver.chrome.service import Service
from webdriver_manager.chrome import ChromeDriverManager
from selenium.webdriver.common.by import By
from selenium.common.exceptions import NoSuchElementException, TimeoutException
from selenium.webdriver.chrome.options import Options
import time
import requests
from amazoncaptcha import AmazonCaptcha
class BaikeNotFoundError(Exception):
    pass

# 主函数
def main():
    source_file = r'failed.txt'
    result_dir = r'20240817'
    # 初始化WebDriver
    driver = webdriver.Chrome()
    # 文件读取评论url
    with open(source_file, 'r',encoding='utf-8')as source:
        resultname = source_file[:-4]+'.json'
        errorname = 'error.txt'
        result_path = os.path.join(result_dir, resultname)
        error_path = os.path.join(result_dir, errorname)

        for line in source:
            url = line.strip()
            print(url)
            content = None
            try:
                # 访问页面
                driver.get(url)
                time.sleep(5)  # 等待页面加载

                # 检测是否是有效的URL
                try:
                    wrong_element = driver.find_element(By.XPATH,
                                                        "/html/body/div[1]/div/a/img")  # /html/body/div[1]/div/a/img
                    continue
                except NoSuchElementException:
                    # 如果没有找到图片元素，可以忽略或处理异常（这里选择忽略）
                    pass

                # 检测是否有验证码
                try:
                    ocr_element = driver.find_element(By.XPATH,
                                                      "/html/body/div[1]/div[1]/div[3]/div/div/form/div[1]/div/div/div[1]/img")  # a-row a-text-center
                    ocr_url = ocr_element.get_attribute('src')
                    captcha = AmazonCaptcha.fromlink(ocr_url)
                    solution = captcha.solve()  # 识别后返回的结果，字符型
                    input_element = driver.find_element(By.XPATH,
                                                        "/html/body/div[1]/div[1]/div[3]/div/div/form/div[1]/div/div/div[2]/input")
                    input_element.clear()  # 清除现有内容
                    input_element.send_keys(solution)
                    button = driver.find_element(By.XPATH,
                                                 "/html/body/div[1]/div[1]/div[3]/div/div/form/div[2]/div/span/span/button")
                    driver.execute_script("arguments[0].click();", button)
                    time.sleep(5)  # 等待页面加载
                except NoSuchElementException:
                    # 如果没有找到图片元素，可以忽略或处理异常（这里选择忽略）
                    pass

                try:
                    # 在评论url下找商品url”
                    good_element = driver.find_element(by=By.XPATH, value="//a[contains(@class, 'a-link-normal')]")
                    good_url = good_element.get_attribute('href')
                    time.sleep(5)
                    # 进入商品页面
                    driver.execute_script("arguments[0].click();", good_element)
                    time.sleep(5)
                    title = ''
                    price = ''
                    intro = ''
                    try:
                        # 解析标题
                        title_element = driver.find_element(by=By.XPATH, value="//span[contains(@id, 'productTitle')]")
                        title = title_element.text
                    except NoSuchElementException:
                        # 如果没有找到em元素，可以忽略或处理异常（这里选择忽略）
                        pass
                    try:
                        # 解析价格
                        price_element = driver.find_element(by=By.XPATH, value="//span[contains(@class, 'a-price')]")
                        price = price_element.text
                    except NoSuchElementException:
                        # 如果没有找到em元素，可以忽略或处理异常（这里选择忽略）
                        pass
                    try:
                        # 解析参数，有几种情况，这里做了一下处理
                        intro_element = driver.find_element(by=By.XPATH,
                                                            value="//div[contains(@id, 'feature-bullets')]")
                        intro = intro_element.text
                    except NoSuchElementException:
                        try:
                            intro_element = driver.find_element(by=By.XPATH,
                                                                value="//div[contains(@id, 'productFactsDesktopExpander')]")
                            intro = intro_element.text
                        except NoSuchElementException:
                            try:
                                intro_element = driver.find_element(by=By.XPATH,
                                                                    value="//div[contains(@id, 'nic-po-expander')]")
                                intro = intro_element.text
                            except NoSuchElementException:
                                # 如果没有找到em元素，可以忽略或处理异常（这里选择忽略）
                                pass
                    content = {'comment_url': url, 'good_url': good_url, 'title': title, 'price': price,
                               'intro': intro}
                    # driver.quit()
                except NoSuchElementException:
                    # 如果没有找到em元素，可以忽略或处理异常（这里选择忽略）
                    pass

            except BaikeNotFoundError as e:
                print(e)
                pass
            except ConnectionRefusedError as e:
                print(e)
                pass

            except ConnectionError as e:
                # 处理ConnectionError异常
                print(f"连接错误: {e}")
                # 可以在这里加入重试逻辑、记录日志或返回错误信息
                pass

            except requests.exceptions.HTTPError as http_err:
                # 处理HTTP错误
                print(f"HTTP错误: {http_err}")
                pass

            except Exception as e:
                print(f"发生错误: {e}")
                # 关闭浏览器（可选）
                # driver.quit()
                pass

            if type(content) == dict:# 以字典格式写入json文件，如果content不是字典格式就是None，将评论url记录，以后可以再次查询。
                with open(result_path,'a', encoding='utf-8') as result:
                    result.write(json.dumps(content,ensure_ascii=False))  # ensure_ascii=False确保非ASCII字符被正确写入，indent=4用于缩进增加可读性
                    result.write('\n')
                result.close()
            else:
                with open(error_path,'a', encoding='utf-8') as error:
                    error.write(url)  # ensure_ascii=False确保非ASCII字符被正确写入，indent=4用于缩进增加可读性
                    error.write('\n')
                error.close()
            time.sleep(random.uniform(10, 60))
    source.close()

if __name__ == '__main__':
    main()