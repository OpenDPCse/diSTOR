from selenium import webdriver
from selenium.common.exceptions import NoSuchElementException
from selenium.webdriver.chrome.service import Service
from webdriver_manager.chrome import ChromeDriverManager
from selenium.webdriver.edge.service import Service
from webdriver_manager.microsoft import EdgeChromiumDriverManager
from selenium.webdriver.common.by import By
from selenium.common.exceptions import NoSuchElementException, TimeoutException
from selenium.webdriver.chrome.options import Options
from selenium.webdriver.edge.options import Options as EdgeOptions
import time
import requests
from amazoncaptcha import AmazonCaptcha

class BaikeNotFoundError(Exception):
    pass


def comment2good(comment_url):
    # 初始化WebDriver
    # chrome_options = Options()
    # chrome_options.add_argument("--headless")
    # # driver = webdriver.Chrome(service=Service(ChromeDriverManager().install()))
    # driver = webdriver.Chrome(service=Service(ChromeDriverManager().install()),options=chrome_options)
    # options = EdgeOptions()
    # options.add_argument('--headless')
    # options.add_argument('--disable-gpu')
    # # 获取msedgedriver的路径
    # driver_path = EdgeChromiumDriverManager().install()
    #
    # # 创建一个Service对象来指定msedgedriver的路径
    # service = Service(executable_path=driver_path)
    #
    # # 使用Service对象来初始化Edge WebDriver
    # # driver = webdriver.Edge(service=service)
    # driver = webdriver.Edge(service=service, options=options)
    driver = webdriver.Edge()
    # driver = webdriver.Chrome()

    # 构造词条页面的URL
    url = comment_url

    try:
        # 访问页面
        driver.get(url)
        time.sleep(5)# 等待页面加载

        # 检测是否是有效的URL
        try:
            wrong_element = driver.find_element(By.XPATH,
                                              "/html/body/div[1]/div/a/img")  # /html/body/div[1]/div/a/img
            # time.sleep(5)  # 等待页面加载
            driver.quit()
            return 'wrong'
        except NoSuchElementException:
            # 如果没有找到图片元素，可以忽略或处理异常（这里选择忽略）
            pass

        # 检测是否有验证码
        try:
            ocr_element = driver.find_element(By.XPATH,
                                              "/html/body/div[1]/div[1]/div[3]/div/div/form/div[1]/div/div/div[1]/img")  # a-row a-text-center
            ocr_url = ocr_element.get_attribute('src')
            captcha = AmazonCaptcha.fromlink(ocr_url)
            solution = captcha.solve()  # 识别后返回的结果，字符型
            input_element = driver.find_element(By.XPATH,
                                              "/html/body/div[1]/div[1]/div[3]/div/div/form/div[1]/div/div/div[2]/input")
            input_element.clear()  # 清除现有内容
            input_element.send_keys(solution)
            button = driver.find_element(By.XPATH,
                                              "/html/body/div[1]/div[1]/div[3]/div/div/form/div[2]/div/span/span/button")
            driver.execute_script("arguments[0].click();", button)
            time.sleep(5)  # 等待页面加载
        except NoSuchElementException:
            # 如果没有找到图片元素，可以忽略或处理异常（这里选择忽略）
            pass

        try:
            # 在评论url下找商品url
            good_element = driver.find_element(by=By.XPATH, value="//a[contains(@class, 'a-link-normal')]")
            good_url = good_element.get_attribute('href')
            time.sleep(5)
            # 进入商品页面
            driver.execute_script("arguments[0].click();", good_element)
            time.sleep(5)
            title = ''
            price = ''
            intro = ''
            try:
                # 解析标题
                title_element = driver.find_element(by=By.XPATH, value="//span[contains(@id, 'productTitle')]")
                title = title_element.text
            except NoSuchElementException:
                # 如果没有找到em元素，可以忽略或处理异常（这里选择忽略）
                pass
            try:
                # 解析价格
                price_element = driver.find_element(by=By.XPATH, value="//span[contains(@class, 'a-price')]")
                price = price_element.text
            except NoSuchElementException:
                try:
                    # 解析价格
                    price_element = driver.find_element(by=By.XPATH, value="//span[contains(@class, 'aok-offscreen')]")
                    price = price_element.text
                except NoSuchElementException:
                    # 如果没有找到em元素，可以忽略或处理异常（这里选择忽略）
                    pass
            try:
                # 解析参数，有几种情况，这里做了一下处理
                intro_element = driver.find_element(by=By.XPATH, value="//div[contains(@id, 'feature-bullets')]")
                intro = intro_element.text
            except NoSuchElementException:
                try:
                    intro_element = driver.find_element(by=By.XPATH,
                                                        value="//div[contains(@id, 'productFactsDesktopExpander')]")
                    intro = intro_element.text
                except NoSuchElementException:
                    try:
                        intro_element = driver.find_element(by=By.XPATH,
                                                            value="//div[contains(@id, 'nic-po-expander')]")
                        intro = intro_element.text
                    except NoSuchElementException:
                        # 如果没有找到em元素，可以忽略或处理异常（这里选择忽略）
                        pass
            content = {'comment_url':comment_url,'good_url':good_url,'title':title,'price':price,'intro':intro}
            driver.quit()
            return content
        except NoSuchElementException:
            # 如果没有找到em元素，可以忽略或处理异常（这里选择忽略）
            # 关闭浏览器（可选）
            driver.quit()
            return None

    except BaikeNotFoundError as e:
        print(e)
        # 关闭浏览器（可选）
        driver.quit()
        return None
    except ConnectionRefusedError as e:
        print(e)
        # 关闭浏览器（可选）
        driver.quit()
        return None

    except ConnectionError as e:
        # 处理ConnectionError异常
        print(f"连接错误: {e}")
        # 可以在这里加入重试逻辑、记录日志或返回错误信息
        driver.quit()
        return None

    except requests.exceptions.HTTPError as http_err:
        # 处理HTTP错误
        print(f"HTTP错误: {http_err}")
        driver.quit()
        return None

    except Exception as e:
        print(f"发生错误: {e}")
        # 关闭浏览器（可选）
        driver.quit()
        return None

# 示例词条名（请替换为实际的词条名）

# goods_url = 'https://www.amazon.com/Payback-Sisterhood-Book-Fern-Michaels-ebook/product-reviews/B000QBYEZU/ref=sr_1_593?sortBy=recent&reviewerType=all_reviews&formatType=current_format'
# # goods_url = 'https://www.amazon.com/-/zh/dp/B0BQ118F2T/ref=sr_1_1?__mk_zh_CN=%E4%BA%9A%E9%A9%AC%E9%80%8A%E7%BD%91%E7%AB%99&crid=1GXWWMCS3HITW&dib=eyJ2IjoiMSJ9.wwKEO2YZjaVbamMrjvBeC9laokd9yjzIQaqPLgItp0N1Rb4U8aUPez7WDoZ4f-7IjCWQm4IPyxKoaETsEPGRDBAQEzdbNxM2O7Cy350Ks7hdz9CrwlGRJ24PK7BVzN5c3WOe7As-9r4tZ7HR6n-yRf2OAx4K0X560oEsxMnT6Dnok5wr-HozNj64hmjuCIR22B2raIn463QMXSwneRnzj6pTytWdsamHO2nrX1UvDiQ.eU1JLRrnssp30HHyxgCzn4JNZQW_fp2wXbdKG1SZ50c&dib_tag=se&keywords=%E6%89%8B%E6%9C%BA&qid=1721805535&sprefix=%E6%89%8B%E6%9C%BA%2Caps%2C698&sr=8-1&th=1'
# content = comment2good(goods_url)
# if content:
#     print(content)


