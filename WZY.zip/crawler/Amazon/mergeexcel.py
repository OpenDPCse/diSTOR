import pandas as pd
import os
import datetime

def main():
    # 假设所有的JSON文件都位于同一个目录下，例如'json_files'
    file1 = r'result_files\2024-07-10_all.xlsx'
    file2 = r'result_files\2024-07-11_16-23-30.xlsx'
    # 获取当前时间
    now = datetime.datetime.now()
    # 格式化时间字符串，例如 "2023-07-19_12-34-56"
    result_name = now.strftime("%Y-%m-%d_%H-%M-%S")+'.xlsx'
    result_file = os.path.join('result_files', result_name)
    sheet_name = 'Sheet1'  # Excel工作表名称

    # 初始化一个空的DataFrame
    data1 = pd.read_excel(file1)
    data2 = pd.read_excel(file2)
    dict1 = data1.to_dict(orient='records')
    dict2 = data2.to_dict(orient='records')
    merged_list = []
    seen_titles = set()  # 使用集合来快速检查标题是否已存在
    # 遍历两个列表
    for lst in [dict1, dict2]:
        for item in lst:
            if item['标题'] not in seen_titles:  # 检查标题是否已存在
                merged_list.append(item)  # 添加到新列表
                seen_titles.add(item['标题'])  # 将标题添加到已见集合

    combined_df = pd.DataFrame(merged_list)
    # 使用ExcelWriter对象来写入Excel文件（如果文件已存在，会被覆盖）
    with pd.ExcelWriter(result_file, engine='openpyxl', mode='w') as writer:
        # 写入Excel文件
        combined_df.to_excel(writer, sheet_name=sheet_name, index=False)

    print(f"所有JSON文件的内容已成功写入{result_file}")
if __name__ == '__main__':
    main()