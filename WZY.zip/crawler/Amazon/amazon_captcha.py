from amazoncaptcha import AmazonCaptcha
from selenium import webdriver
from selenium.common.exceptions import NoSuchElementException
from selenium.webdriver.common.by import By
import time

driver = webdriver.Chrome()
driver.get('https://www.amazon.com/errors/validateCaptcha')
time.sleep(10)
ocr_url=''
try:
    ocr_element = driver.find_element(By.XPATH, "/html/body/div[1]/div[1]/div[3]/div/div/form/div[1]/div/div/div[1]/img")# a-row a-text-center
    ocr_url = ocr_element.get_attribute('src')
    print(ocr_url)
except NoSuchElementException:
    # 如果没有找到em元素，可以忽略或处理异常（这里选择忽略）
    pass
captcha = AmazonCaptcha.fromlink(ocr_url)
solution = captcha.solve()#识别后返回的结果，字符型
