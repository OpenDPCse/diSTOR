import pandas as pd
import os
import datetime
import json

def main():
    # 假设所有的JSON文件都位于同一个目录下，例如'json_files'
    json_dir = r'20240728'
    result_dir = r'20240728'
    # 获取当前时间
    # now = datetime.datetime.now()
    # 格式化时间字符串，例如 "2023-07-19_12-34-56"
    # excel_name = now.strftime("%Y-%m-%d_%H-%M-%S")+'.xlsx'
    # excel_file = os.path.join(result_dir, excel_name)
    # sheet_name = 'Sheet1'  # Excel工作表名称
    result_name = 'failed.txt'
    result_file = os.path.join(result_dir, result_name)

    # 初始化一个空的DataFrame
    all_data = pd.DataFrame()
    # 使用ExcelWriter对象来写入Excel文件（如果文件已存在，会被覆盖）
    with open(result_file, mode='w',encoding='utf-8') as failed:
        for filename in os.listdir(json_dir):
            if filename.endswith('.json'):  # 确保文件是JSON格式
                file_path = os.path.join(json_dir, filename)
                # 读取JSON文件
                with open (file_path,'r',encoding='utf-8') as rf:
                    for line in rf:
                        data = json.loads(line.strip())
                        if data['title'] == '':
                            failed.write(data['comment_url'])
                            failed.write('\n')
                            # print(data['comment_url'])


if __name__ == '__main__':
    main()