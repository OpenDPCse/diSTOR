import random
import time
import json
import os
import json2excel
import comment2good


# 主函数
def main():
    source_file = r'failed.txt'
    result_dir = r'20240817'
    # 文件读取评论url
    with open(source_file, 'r',encoding='utf-8')as source:
        resultname = source_file[:-4]+'.json'
        errorname = 'error.txt'
        result_path = os.path.join(result_dir, resultname)
        error_path = os.path.join(result_dir, errorname)
        for line in source:
            url = line.strip()
            print(url)
            content = comment2good.comment2good(url)# 调用comment2good中的函数，返回评论url、商品url、标题、价格、参数
            if type(content) == dict:# 以字典格式写入json文件，如果content不是字典格式就是None，将评论url记录，以后可以再次查询。
                # 判断是真的商品url还是帮助页面
                if content['title'] == '':# 说明是帮助页面的链接
                    with open(error_path, 'a', encoding='utf-8') as error:
                        error.write(url)  # ensure_ascii=False确保非ASCII字符被正确写入，indent=4用于缩进增加可读性
                        error.write('\n')
                    error.close()
                else:
                    with open(result_path,'a', encoding='utf-8') as result:
                        result.write(json.dumps(content,ensure_ascii=False))  # ensure_ascii=False确保非ASCII字符被正确写入，indent=4用于缩进增加可读性
                        result.write('\n')
                    result.close()
            elif content is None:
                with open(error_path,'a', encoding='utf-8') as error:
                    error.write(url)  # ensure_ascii=False确保非ASCII字符被正确写入，indent=4用于缩进增加可读性
                    error.write('\n')
                error.close()
            else:
                pass
            time.sleep(random.uniform(20, 60))
    source.close()

if __name__ == '__main__':
    main()