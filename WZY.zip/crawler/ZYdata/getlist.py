from selenium import webdriver
from selenium.webdriver.common.by import By
from selenium.common.exceptions import NoSuchElementException, TimeoutException
import time
import requests
class BaikeNotFoundError(Exception):
    pass

def fetch_baidubaike_content(comment_url):
    # 初始化WebDriver
    # chrome_options = Options()
    # chrome_options.add_argument("--headless")
    # # driver = webdriver.Chrome(service=Service(ChromeDriverManager().install()))
    # driver = webdriver.Chrome(service=Service(ChromeDriverManager().install()),options=chrome_options)
    # options = EdgeOptions()
    # options.add_argument('--headless')
    # options.add_argument('--disable-gpu')
    # # 获取msedgedriver的路径
    # driver_path = EdgeChromiumDriverManager().install()
    #
    # # 创建一个Service对象来指定msedgedriver的路径
    # service = Service(executable_path=driver_path)
    #
    # # 使用Service对象来初始化Edge WebDriver
    # # driver = webdriver.Edge(service=service)
    # driver = webdriver.Edge(service=service, options=options)
    driver = webdriver.Edge()
    # driver = webdriver.Chrome()

    # 构造词条页面的URL
    url = comment_url

    try:
        # 访问页面
        driver.get(url)
        time.sleep(5)# 等待页面加载
        parent_element = driver.find_element(by=By.XPATH, value="/html/body/div[1]/div/div[2]/div[2]/div/div[1]/div/div[6]")
        child_elements = parent_element.find_elements(By.XPATH,'./div')  # 找到div[6]下的所有div
        for child in child_elements:
            # 获取div的class属性
            class_attribute = child.get_attribute('class')

            # 检查'para_vJPDN'是否存在于class属性中
            if 'para_vJPDN' in class_attribute:
                print(child.text)
                try:
                    a_tags = child.find_elements(By.TAG_NAME,'a')
                    for a in a_tags:
                        href = a.get_attribute('href')
                        print(href)
                except Exception as e:
                    pass

        driver.quit()
        return None




    except BaikeNotFoundError as e:
        print(e)
        # 关闭浏览器（可选）
        driver.quit()
        return None
    except ConnectionRefusedError as e:
        print(e)
        # 关闭浏览器（可选）
        driver.quit()
        return None

    except ConnectionError as e:
        # 处理ConnectionError异常
        print(f"连接错误: {e}")
        # 可以在这里加入重试逻辑、记录日志或返回错误信息
        driver.quit()
        return None

    except requests.exceptions.HTTPError as http_err:
        # 处理HTTP错误
        print(f"HTTP错误: {http_err}")
        driver.quit()
        return None

    except Exception as e:
        print(f"发生错误: {e}")
        # 关闭浏览器（可选）
        driver.quit()
        return None

url = 'https://baike.baidu.com/item/%E4%B8%96%E7%95%8C%E5%90%84%E5%9B%BD%E5%9B%BD%E5%AE%B6%E5%85%83%E9%A6%96%E3%80%81%E6%94%BF%E5%BA%9C%E9%A6%96%E8%84%91%E4%B8%8E%E5%A4%96%E9%95%BF/9012117'
content = fetch_baidubaike_content(url)
if content:
    print(content)